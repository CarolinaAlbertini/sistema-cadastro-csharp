﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GABCAR
{
    public partial class CadEmpregado : Form
    {
        private SqlConnection conexao;
        private SqlCommand comando;
        private string strsql, strconex;
        private SqlDataAdapter adapter;
        private DataTable tblSetores;

        public CadEmpregado()
        {
            InitializeComponent();
        }


            private void lblcbosetor_Click(object sender, EventArgs e)
        {

            
        }

        private void cbocodsetor_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblcbosetor.Text = cbocodsetor.SelectedValue.ToString();
        }

        private void CadEmpregado_Load(object sender, EventArgs e)
        {
            MessageBox.Show("O formulário começou a carregar!");

            strconex = "data source=(local);initial catalog=RHsolucoes;" +
           "integrated security=true";

            conexao = new SqlConnection(strconex);
            conexao.Open();

            tblSetores = new DataTable();
            strsql = "select * from Setores";
            adapter = new SqlDataAdapter(strsql, conexao);
            adapter.Fill(tblSetores);

            cbocodsetor.DataSource = tblSetores;
            cbocodsetor.DisplayMember = "Setor";
            cbocodsetor.ValueMember = "Codsetor";

            lblcbosetor.Text = cbocodsetor.SelectedValue.ToString();
        
    }

        private void button3_Click(object sender, EventArgs e)
        {
            CadSetor tela = new CadSetor();
            tela.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            strconex = "data source=(local);initial catalog=RHsolucoes;" + "integrated security=true";
            conexao = new SqlConnection(strconex);
            conexao.Open();

            strsql = "insert into Empregados (Empregado,Bairro,Cidade,CodSetor) " +
                 " VALUES ('" + txtempregado.Text + "' , '" + txtbairro.Text + "' , '" + txtcidade.Text + "', '" + cbocodsetor.SelectedValue + "')";


            comando = new SqlCommand(strsql, conexao);
            comando.ExecuteNonQuery();

            MessageBox.Show("Registro gravado com Sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
