Use master 
GO
if exists (select * from sysdatabases where name = 'RHsolucoes')
      drop database RHsolucoes

CREATE DATABASE RHsolucoes
--USE RHsolucoes;
--GO

	CREATE TABLE Empregados(
        Codempregados int identity (1,1) primary key,
        Empregado    nvarchar (50)not null,
        Bairro   nvarchar (50) not null,
        Cidade      nvarchar (50) not null,
       Codsetor	int				not null		                             
)

select * from Empregados

insert into Empregados (Empregado,Bairro, Cidade,Codsetor)
       values ('Marcelo Aguiar','Mooca', 'São Paulo',1)
       
insert into Empregados (Empregado,Bairro, Cidade,Codsetor)
       values ('Marcos Luis Fernandes','Prudente', 'São Paulo',2)

	CREATE TABLE Setores(
      Codsetor	int				not null		identity (1,1)		primary key ,
      setor		nvarchar (15)	not null,
      Descricao		nvarchar (150)  null,
 )

 select * from Setores

 insert into Setores (setor,Descricao) 
       values ('Marketing', 'Publicidade dos Produtos')

 insert into Setores (setor,Descricao)
       values ('Vendas', 'Vende os Produtos')




    
